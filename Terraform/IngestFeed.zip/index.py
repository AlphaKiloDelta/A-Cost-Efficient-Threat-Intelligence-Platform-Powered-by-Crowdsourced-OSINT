import requests
import pymongo
import json
import os

def lambda_handler(event, context):
	params = {'query':'get_recent','selector':'time'}
	r = requests.post('https://mb-api.abuse.ch/api/v1', data=params).text
	data = json.loads(r)
              
	r = requests.get('https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem')
	caCert = open('/tmp/global-bundle.pem', 'wb')
	caCert.write(r.content)
	caCert.close()
              
	client = pymongo.MongoClient('mongodb://'+os.environ['USERNAME']+':'+os.environ['PASSWORD']+'@'+os.environ['CLUSTER']+':27017/?tls=true&tlsCAFile=/tmp/global-bundle.pem&replicaSet=rs0&readPreference=secondaryPreferred&retryWrites=true')
	db = client.tip
    collection = db.tip_collection
    collection.insert_one(data)
    client.close()